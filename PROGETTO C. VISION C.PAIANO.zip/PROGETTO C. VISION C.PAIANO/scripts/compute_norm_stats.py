import os
import argparse
import pandas as pd
import numpy as np
import json
import sys
from tqdm import tqdm

# Aggiungiamo la root del progetto al path di sistema
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.utils import set_seed, get_logger, load_config
from src.preprocessing import load_image, build_three_channel

logger = get_logger("compute_norm_stats")

def compute_stats_single_pass(csv_path: str, clahe_limits: list) -> dict:
    """
    Calcola media e deviazione standard per canale in una singola passata.
    Questo approccio evita di caricare l'intero dataset in RAM (memoria costante).
    """
    df = pd.read_csv(csv_path)
    n_pixels = 0
    channel_sum = np.zeros(3, dtype=np.float64)
    channel_sq_sum = np.zeros(3, dtype=np.float64)
    
    logger.info(f"Calcolo statistiche su {len(df)} immagini di training...")
    
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Elaborazione immagini"):
        # Carica immagine
        img = load_image(row['filepath'])
        
        # Simula lo stesso preprocessing che avrà il modello deep (3 canali con CLAHE)
        img_3c = build_three_channel(img, clahe_limits)
        
        # Normalizza in range [0, 1] per il calcolo
        img_norm = img_3c.astype(np.float32) / 255.0
        
        # Aggiorna i contatori
        n_pixels += img_norm.shape[0] * img_norm.shape[1]
        channel_sum += np.sum(img_norm, axis=(0, 1))
        channel_sq_sum += np.sum(img_norm ** 2, axis=(0, 1))
        
    mean = channel_sum / n_pixels
    std = np.sqrt((channel_sq_sum / n_pixels) - (mean ** 2))
    
    return {
        "mean": [round(float(m), 3) for m in mean],
        "std": [round(float(s), 3) for s in std],
        "n_images": len(df),
        "lung_mask": False # Come indicato nella guida, qui salviamo False per coerenza col file fornito
    }

def main():
    parser = argparse.ArgumentParser(description="Calcola media e std del training set.")
    parser.add_argument('--config', type=str, default='configs/default.yaml')
    args = parser.parse_args()
    
    config = load_config(args.config)
    set_seed(config['data']['seed'])
    
    train_csv = os.path.join(config['data']['processed_dir'], 'train_split.csv')
    clahe_limits = config['preprocessing']['clahe_clip_limits']
    
    if not os.path.exists(train_csv):
        logger.error(f"File {train_csv} non trovato. Esegui prima prepare_data.py")
        return
        
    stats = compute_stats_single_pass(train_csv, clahe_limits)
    
    out_file = os.path.join('configs', 'norm_stats.json')
    with open(out_file, 'w') as f:
        json.dump(stats, f, indent=4)
        
    logger.info(f"Statistiche salvate in {out_file}: Media={stats['mean']}, Std={stats['std']}")

if __name__ == '__main__':
    main()