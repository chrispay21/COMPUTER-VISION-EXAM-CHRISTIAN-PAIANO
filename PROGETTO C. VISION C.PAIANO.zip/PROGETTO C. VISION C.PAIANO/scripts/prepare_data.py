import os
import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
import sys

# Aggiungiamo la root del progetto al path di sistema per poter importare 'src'
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.utils import set_seed, get_logger, load_config

logger = get_logger("prepare_data")

def scan_dataset(raw_dir: str) -> pd.DataFrame:
    """
    Scansiona le cartelle COVID e non-COVID (e tutte le loro sottocartelle)
    e crea un DataFrame con i percorsi dei file e le etichette.
    """
    data = []
    classes = ['covid', 'non-covid']
    
    for cls in classes:
        cls_dir = os.path.join(raw_dir, cls)
        if not os.path.exists(cls_dir):
            logger.warning(f"Attenzione: la cartella {cls_dir} non esiste!")
            continue
            
        # os.walk cerca automaticamente in tutte le sottocartelle (es. Patient (1)...)
        for root, _, files in os.walk(cls_dir):
            for filename in sorted(files):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    data.append({
                        'filepath': os.path.join(root, filename),
                        'label': cls
                    })
                
    df = pd.DataFrame(data)
    logger.info(f"Trovate {len(df)} immagini in totale.")
    return df

def make_splits(df: pd.DataFrame, seed: int) -> tuple:
    """
    Divide il dataset in Train (70%), Validation (15%) e Test (15%).
    Usa lo split stratificato per mantenere le proporzioni delle classi.
    """
    # Primo split: 70% Train, 30% temporaneo (Val + Test)
    train_df, temp_df = train_test_split(
        df, test_size=0.30, random_state=seed, stratify=df['label']
    )
    
    # Secondo split: divide il 30% temporaneo a metà -> 15% Val, 15% Test
    val_df, test_df = train_test_split(
        temp_df, test_size=0.50, random_state=seed, stratify=temp_df['label']
    )
    
    logger.info(f"Split completato:")
    logger.info(f" - Training: {len(train_df)} immagini")
    logger.info(f" - Validation: {len(val_df)} immagini")
    logger.info(f" - Test: {len(test_df)} immagini")
    
    return train_df, val_df, test_df

def main():
    parser = argparse.ArgumentParser(description="Prepara i CSV con gli split del dataset.")
    parser.add_argument('--config', type=str, default='configs/default.yaml', help='Percorso del file YAML')
    args = parser.parse_args()
    
    config = load_config(args.config)
    seed = config['data']['seed']
    set_seed(seed)
    
    raw_dir = config['data']['raw_dir']
    processed_dir = config['data']['processed_dir']
    
    # Creiamo la cartella di destinazione se non esiste
    os.makedirs(processed_dir, exist_ok=True)
    
    # 1. Scansiona i dati
    df = scan_dataset(raw_dir)
    
    if len(df) == 0:
        logger.error("Nessuna immagine trovata. Assicurati di aver messo i file in data/raw/covid e data/raw/non-covid")
        return
        
    # 2. Crea gli split
    train_df, val_df, test_df = make_splits(df, seed)
    
    # 3. Salva i CSV
    train_df.to_csv(os.path.join(processed_dir, 'train_split.csv'), index=False)
    val_df.to_csv(os.path.join(processed_dir, 'val_split.csv'), index=False)
    test_df.to_csv(os.path.join(processed_dir, 'test_split.csv'), index=False)
    
    logger.info(f"File CSV salvati con successo in {processed_dir}/")

if __name__ == '__main__':
    main()