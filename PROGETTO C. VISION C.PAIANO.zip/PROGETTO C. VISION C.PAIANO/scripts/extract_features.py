import os
import argparse
import pandas as pd
import numpy as np
import sys
from tqdm import tqdm

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.utils import set_seed, get_logger, load_config
from src.preprocessing import load_image, _otsu_fallback
from src.features import extract_handcrafted_features

logger = get_logger("extract_features")

def process_split(csv_path: str, out_path: str, apply_mask: bool):
    """
    Legge un CSV, estrae le feature per ogni immagine e salva array Numpy.
    """
    if not os.path.exists(csv_path):
        logger.error(f"File {csv_path} non trovato.")
        return
        
    df = pd.read_csv(csv_path)
    features_list = []
    labels_list = []
    
    logger.info(f"Estrazione feature per {csv_path} (Maschera: {apply_mask})...")
    
    for _, row in tqdm(df.iterrows(), total=len(df)):
        img = load_image(row['filepath'])
        
        # Assicuriamoci che l'immagine sia in scala di grigi per le feature handcrafted
        import cv2
        if len(img.shape) == 3:
            img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        else:
            img_gray = img
            
        mask = None
        if apply_mask:
            mask = _otsu_fallback(img_gray)
            
        features = extract_handcrafted_features(img_gray, lung_mask=mask)
        
        features_list.append(features)
        labels_list.append(1 if row['label'] == 'covid' else 0)
        
    # Salva in formato compresso per risparmiare spazio
    np.savez_compressed(
        out_path, 
        X=np.array(features_list), 
        y=np.array(labels_list)
    )
    logger.info(f"Salvato {out_path} con shape X={np.array(features_list).shape}")

def main():
    parser = argparse.ArgumentParser(description="Estrae le feature classiche e le salva in file NPZ.")
    parser.add_argument('--config', type=str, default='configs/default.yaml')
    args = parser.parse_args()
    
    config = load_config(args.config)
    set_seed(config['data']['seed'])
    
    processed_dir = config['data']['processed_dir']
    use_mask = config['preprocessing']['lung_mask']
    
    splits = ['train', 'val', 'test']
    
    for split in splits:
        csv_path = os.path.join(processed_dir, f'{split}_split.csv')
        out_path = os.path.join(processed_dir, f'{split}_features.npz')
        process_split(csv_path, out_path, use_mask)

if __name__ == '__main__':
    main()