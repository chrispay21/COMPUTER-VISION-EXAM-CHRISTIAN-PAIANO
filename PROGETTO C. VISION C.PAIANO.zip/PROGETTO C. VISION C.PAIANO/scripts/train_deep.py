import os
import argparse
import pandas as pd
import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.utils import set_seed, get_logger, load_config
from src.preprocessing import get_train_transform, get_eval_transform
from src.models.deep import CovidCTDataset, build_model, unfreeze_last_blocks
from src.evaluate import compute_metrics

logger = get_logger("train_deep")

def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    running_loss = 0.0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
    return running_loss / len(loader)

def validate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    all_preds, all_probs, all_labels = [], [], []
    
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            logits = model(images)
            loss = criterion(logits, labels)
            running_loss += loss.item()
            
            probs = torch.softmax(logits, dim=1)[:, 1]
            preds = torch.argmax(logits, dim=1)
            
            all_probs.extend(probs.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            
    val_loss = running_loss / len(loader)
    metrics = compute_metrics(all_labels, all_preds, all_probs)
    return val_loss, metrics

def main():
    parser = argparse.ArgumentParser(description="Addestra la rete EfficientNet a due fasi.")
    parser.add_argument('--config', type=str, default='configs/default.yaml')
    args = parser.parse_args()
    
    config = load_config(args.config)
    set_seed(config['data']['seed'])
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Avvio training su device: {device}")
    
    # Setup dati
    train_df = pd.read_csv(os.path.join(config['data']['processed_dir'], 'train_split.csv'))
    val_df = pd.read_csv(os.path.join(config['data']['processed_dir'], 'val_split.csv'))
    test_df = pd.read_csv(os.path.join(config['data']['processed_dir'], 'test_split.csv'))
    
    train_loader = DataLoader(CovidCTDataset(train_df, get_train_transform()), 
                              batch_size=config['training']['batch_size'], shuffle=True)
    val_loader = DataLoader(CovidCTDataset(val_df, get_eval_transform()), 
                            batch_size=config['training']['batch_size'])
    test_loader = DataLoader(CovidCTDataset(test_df, get_eval_transform()), 
                             batch_size=config['training']['batch_size'])
    
    model = build_model(config).to(device)
    criterion = nn.CrossEntropyLoss()
    os.makedirs('models/deep', exist_ok=True)
    best_val_loss = float('inf')
    best_model_path = 'models/deep/efficientnet_best.pth'
    
    # FASE 1: Allena solo la testa
    logger.info("=== FASE 1: Addestramento Testa ===")
    optimizer_1 = torch.optim.Adam(model.head.parameters(), lr=config['training']['learning_rate_phase1'])
    
    for epoch in range(config['training']['epochs_phase1']):
        train_loss = train_one_epoch(model, train_loader, optimizer_1, criterion, device)
        val_loss, val_metrics = validate(model, val_loader, criterion, device)
        logger.info(f"Fase 1 - Epoca {epoch+1} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Val AUC: {val_metrics['auc_roc']:.4f}")
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), best_model_path)
            
    # FASE 2: Fine-Tuning strati finali
    logger.info("=== FASE 2: Fine-Tuning parziale ===")
    model.load_state_dict(torch.load(best_model_path, weights_only=True)) # Ricarica il migliore
    unfreeze_last_blocks(model, n_blocks=2)
    
    optimizer_2 = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), 
                                    lr=config['training']['learning_rate_phase2'], 
                                    weight_decay=config['training']['weight_decay'])
    
    for epoch in range(config['training']['epochs_phase2']):
        train_loss = train_one_epoch(model, train_loader, optimizer_2, criterion, device)
        val_loss, val_metrics = validate(model, val_loader, criterion, device)
        logger.info(f"Fase 2 - Epoca {epoch+1} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Val AUC: {val_metrics['auc_roc']:.4f}")
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), best_model_path)
            
    # Valutazione finale sul TEST SET
    logger.info("=== Valutazione sul Test Set ===")
    model.load_state_dict(torch.load(best_model_path, weights_only=True))
    _, test_metrics = validate(model, test_loader, criterion, device)
    
    with open('logs/test_results.json', 'w') as f:
        json.dump(test_metrics, f, indent=4)
        
    logger.info(f"Training completato. Test AUC-ROC: {test_metrics['auc_roc']:.4f}")

if __name__ == '__main__':
    main()