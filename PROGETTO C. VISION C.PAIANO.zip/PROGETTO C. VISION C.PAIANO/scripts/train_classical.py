import os
import argparse
import numpy as np
import json
import joblib
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.utils import set_seed, get_logger, load_config
from src.models.classical import train_svm, train_random_forest
from src.evaluate import compute_metrics

logger = get_logger("train_classical")

def load_data(npz_path: str):
    data = np.load(npz_path)
    return data['X'], data['y']

def main():
    parser = argparse.ArgumentParser(description="Addestra SVM e Random Forest sulle feature handcrafted.")
    parser.add_argument('--config', type=str, default='configs/default.yaml')
    args = parser.parse_args()
    
    config = load_config(args.config)
    seed = config['data']['seed']
    set_seed(seed)
    
    processed_dir = config['data']['processed_dir']
    
    # Caricamento feature
    logger.info("Caricamento feature estratte...")
    X_train, y_train = load_data(os.path.join(processed_dir, 'train_features.npz'))
    X_test, y_test = load_data(os.path.join(processed_dir, 'test_features.npz'))
    
    # Cartelle di output
    os.makedirs('models/classical', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    results = {}

    # 1. Addestramento Random Forest
    logger.info("Avvio addestramento Random Forest...")
    rf_model = train_random_forest(X_train, y_train, random_state=seed)
    # Valutazione RF
    rf_probs = rf_model.predict_proba(X_test)[:, 1]
    rf_preds = rf_model.predict(X_test)
    results['random_forest'] = compute_metrics(y_test, rf_preds, rf_probs)
    # Salva modello
    joblib.dump(rf_model, 'models/classical/rf.pkl')
    
    # 2. Addestramento SVM (con PCA interna)
    logger.info("Avvio addestramento SVM (potrebbe richiedere un po' di tempo per la PCA)...")
    svm_model = train_svm(X_train, y_train, random_state=seed)
    # Valutazione SVM
    svm_probs = svm_model.predict_proba(X_test)[:, 1]
    svm_preds = svm_model.predict(X_test)
    results['svm'] = compute_metrics(y_test, svm_preds, svm_probs)
    # Salva modello
    joblib.dump(svm_model, 'models/classical/svm.pkl')
    
    # Salva metriche
    with open('logs/classical_results.json', 'w') as f:
        json.dump(results, f, indent=4)
        
    logger.info("Addestramento classico completato! Risultati salvati in logs/classical_results.json")

if __name__ == '__main__':
    main()