# 🫁 Classificatore COVID-19 da TAC: Un Approccio Ibrido di Computer Vision

## 📌 Panoramica del Progetto
Questo progetto fornisce una pipeline automatizzata di Computer Vision per la classificazione di TAC toraciche come positive o negative al COVID-19. Sviluppato come prototipo di supporto decisionale clinico, risponde alla necessità critica di un triage rapido e affidabile in scenari pandemici ad alto carico. La repository dimostra un flusso di lavoro completo (end-to-end), mettendo a confronto tecniche classiche di Machine Learning con architetture di Deep Learning.

## 🏗️ Pipeline e Architettura
Il sistema è basato su una pipeline altamente modulare progettata per prevenire il data leakage (splitting a livello di paziente) e massimizzare l'interpretabilità clinica:

1. **Acquisizione e Preprocessing dei Dati:**
   * **Filtro Gaussiano:** Applicato per ridurre il rumore intra-parenchimale dello scanner.
   * **Soglia di Otsu e Operazioni Morfologiche:** Utilizzate per segmentare automaticamente il parenchima polmonare, mascherando il letto del paziente, i tessuti molli esterni e le ossa, per garantire che i modelli apprendano solo dalle caratteristiche anatomiche rilevanti.

2. **Feature Engineering (Approccio Classico):**
   * **HOG (Histogram of Oriented Gradients):** Estrae informazioni strutturali e transizioni dei bordi.
   * **LBP (Local Binary Patterns):** Cattura le micro-variazioni di texture tipiche delle opacità a vetro smerigliato del COVID-19.
   * *Riduzione della Dimensionalità:* La Principal Component Analysis (PCA) viene utilizzata per gestire lo spazio delle feature ad altissima dimensionalità (>26.000 dimensioni).

3. **Modelli Principali:**
   * **Machine Learning Classico:** Support Vector Machine (SVM) e Random Forest, ottimizzati tramite Grid Search Cross-Validation.
   * **Deep Learning:** Architettura EfficientNet-B0 utilizzando il Transfer Learning (pesi di ImageNet) con una testata di classificazione personalizzata.

4. **Post-elaborazione e Inferenza Avanzata:**
   * **Test-Time Augmentation (TTA):** Il modello Deep Learning aggrega le predizioni su molteplici perturbazioni geometriche dell'immagine di test per ridurre drasticamente i falsi negativi.

## 📊 Riepilogo dei Risultati
I modelli sono stati valutati su un Test Set rigorosamente mai visto prima in fase di addestramento. La pipeline di Computer Vision Classica ha dimostrato un'eccezionale robustezza, con la **Support Vector Machine (SVM)** che è risultata il modello più performante per questo specifico spazio di feature:

* **Prestazioni SVM (PCA-200):**
  * **AUC-ROC:** 99.63%
  * **Recall:** 96.80% (Fondamentale per ridurre al minimo i Falsi Negativi nello screening medico).
* L'approccio Deep Learning (EfficientNet) ha mostrato metriche competitive paragonabili, agendo come estrattore di feature end-to-end. Metriche dettagliate e matrici di confusione sono disponibili nella directory `logs/`.

## 🚀 Istruzioni per l'Installazione e l'Avvio

### Prerequisiti e Informazioni sui Dati
* Python 3.9+
* macOS/Linux/Windows
* **Nota sul Dataset:** Il dataset originale utilizzato per l'addestramento è quello Brasiliano (licenza CC BY 4.0) per il COVID-19. Non è allegato a questa repository per limiti di spazio (peso eccessivo), ma le istruzioni sottostanti permettono di scaricare le feature estratte e ricreare l'ambiente.

### 1. Installazione
link al dataset di immagini
https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/SZDUQX

Clona la repository e naviga nella directory del progetto:
```bash
git clone [https://github.com/chrispay21/COMPUTER-VISION-EXAM-CHRISTIAN-PAIANO.git](https://github.com/chrispay21/COMPUTER-VISION-EXAM-CHRISTIAN-PAIANO.git)
cd "PROGETTO C. VISION C.PAIANO"

python -m venv venv
source venv/bin/activate  # Su Windows usa: venv\Scripts\activate

pip install -r requirements.txt
export PYTHONPATH="."

streamlit run app/demo.py

# 1. Estrazione delle feature classiche (HOG, LBP)
python scripts/extract_features.py

# 2. Addestramento dei modelli classici (SVM, Random Forest)
python scripts/train_classical.py

Link al Notebook Colab: https://colab.research.google.com/drive/1CqnX3-FNBHRQIgq6p6XSZLwLy8sPA2D2?usp=sharing