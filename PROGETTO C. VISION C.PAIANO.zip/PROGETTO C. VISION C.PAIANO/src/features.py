import cv2
import numpy as np
from skimage.feature import local_binary_pattern, graycomatrix, graycoprops, hog
from src.preprocessing import apply_lung_mask

def extract_lbp(img_gray: np.ndarray, P: int = 24, R: int = 3) -> np.ndarray:
    """
    Estrae le feature Local Binary Pattern (LBP) per analizzare la texture.
    Ritorna l'istogramma normalizzato dei pattern uniformi.
    Ottimo per identificare l'opacità a 'vetro smerigliato' tipica del COVID.
    """
    lbp = local_binary_pattern(img_gray, P, R, method="uniform")
    n_bins = int(lbp.max() + 1)
    hist, _ = np.histogram(lbp.ravel(), bins=n_bins, range=(0, n_bins), density=True)
    return hist

def extract_glcm(img_gray: np.ndarray, distances: list = [1, 2, 3, 4], angles: list = [0, np.pi/4, np.pi/2, 3*np.pi/4]) -> np.ndarray:
    """
    Estrae le proprietà statistiche dalla Gray-Level Co-occurrence Matrix (GLCM).
    Quantizza l'immagine a 64 livelli per velocizzare il calcolo.
    """
    # Quantizzazione da 256 a 64 livelli di grigio
    img_quantized = (img_gray / 4).astype(np.uint8)
    
    glcm = graycomatrix(img_quantized, distances=distances, angles=angles, 
                        levels=64, symmetric=True, normed=True)
    
    properties = ['contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'correlation']
    features = []
    
    for prop in properties:
        # Estrae le proprietà e le appiattisce in un array 1D
        prop_vals = graycoprops(glcm, prop).ravel()
        features.extend(prop_vals)
        
    return np.array(features)

def extract_hog(img_gray: np.ndarray) -> np.ndarray:
    """
    Estrae l'Histogram of Oriented Gradients (HOG) per catturare la forma.
    Produce un vettore molto grande (dominante nel set finale).
    """
    # Ridimensioniamo a una dimensione fissa (224x224) per garantire un vettore in uscita di taglia costante
    img_resized = cv2.resize(img_gray, (224, 224), interpolation=cv2.INTER_AREA)
    
    features = hog(img_resized, orientations=9, pixels_per_cell=(8, 8),
                   cells_per_block=(2, 2), block_norm='L2-Hys', visualize=False, 
                   feature_vector=True)
    return features

def extract_handcrafted_features(img_gray: np.ndarray, lung_mask: np.ndarray = None) -> np.ndarray:
    """
    Concatena LBP, GLCM e HOG in un unico vettore di 26.366 feature.
    Se fornita, applica la maschera polmonare prima dell'estrazione per 
    eliminare il rumore di fondo.
    """
    if lung_mask is not None:
        img_gray = apply_lung_mask(img_gray, lung_mask)
        
    lbp_feat = extract_lbp(img_gray)
    glcm_feat = extract_glcm(img_gray)
    hog_feat = extract_hog(img_gray)
    
    return np.concatenate([lbp_feat, glcm_feat, hog_feat])