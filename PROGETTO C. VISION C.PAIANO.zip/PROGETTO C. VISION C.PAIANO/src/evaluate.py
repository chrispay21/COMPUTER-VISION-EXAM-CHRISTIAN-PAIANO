import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_curve, auc, brier_score_loss, precision_recall_curve
)
from src.utils import get_logger

logger = get_logger(__name__)

def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_probs: np.ndarray) -> dict:
    """Calcola tutte le metriche di valutazione richieste per l'esame."""
    metrics = {}
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
    metrics['f1'] = f1_score(y_true, y_pred, zero_division=0)
    
    cm = confusion_matrix(y_true, y_pred)
    if cm.shape == (1, 1):
        cm_full = np.zeros((2, 2), dtype=int)
        cm_full[y_true[0], y_pred[0]] = cm[0, 0]
        cm = cm_full
        
    tn, fp, fn, tp = cm.ravel()
    metrics['specificity'] = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    
    fpr, tpr, _ = roc_curve(y_true, y_probs)
    metrics['auc_roc'] = auc(fpr, tpr)
    metrics['brier_score'] = brier_score_loss(y_true, y_probs)
    
    logger.info(f"Valutazione completata. AUC-ROC: {metrics['auc_roc']:.4f}, Recall: {metrics['recall']:.4f}")
    return metrics

def plot_confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray, save_path: str = None):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['Non-COVID', 'COVID'], yticklabels=['Non-COVID', 'COVID'])
    plt.ylabel('Verità')
    plt.xlabel('Predizione')
    plt.title('Matrice di Confusione')
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.close()

def plot_roc_curve(y_true: np.ndarray, y_probs: np.ndarray, save_path: str = None):
    fpr, tpr, _ = roc_curve(y_true, y_probs)
    roc_auc = auc(fpr, tpr)
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate (Recall)')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    plt.close()