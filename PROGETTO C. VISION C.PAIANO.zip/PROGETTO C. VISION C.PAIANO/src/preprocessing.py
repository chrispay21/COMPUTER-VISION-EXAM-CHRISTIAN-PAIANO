import cv2
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2
from src.utils import get_logger

logger = get_logger(__name__)

def load_image(path: str) -> np.ndarray:
    """
    Legge un'immagine PNG, gestisce i vari formati (RGB, RGBA, Grayscale)
    e la converte in formato uint8 (0-255).
    """
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError(f"Impossibile leggere l'immagine al percorso: {path}")

    # Gestione profondità colore (converte 16-bit in 8-bit)
    if img.dtype == np.uint16:
        img = (img / 256).astype(np.uint8)

    # Gestione canali
    if len(img.shape) == 2:
        # Immagine in scala di grigi, la portiamo a RGB
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    elif len(img.shape) == 3 and img.shape[2] == 4:
        # Rimuove il canale Alpha se presente (RGBA -> RGB)
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)
    elif len(img.shape) == 3 and img.shape[2] == 3:
        # OpenCV legge in BGR, convertiamo in RGB
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
    return img

def resize_with_padding(img: np.ndarray, target_size: int = 224) -> np.ndarray:
    """
    Ridimensiona l'immagine preservando le proporzioni (aspect ratio) 
    e aggiungendo bande nere (padding) per arrivare alla target_size.
    """
    h, w = img.shape[:2]
    scale = target_size / max(h, w)
    new_h, new_w = int(h * scale), int(w * scale)
    
    resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)
    
    # Calcola il padding necessario
    top = (target_size - new_h) // 2
    bottom = target_size - new_h - top
    left = (target_size - new_w) // 2
    right = target_size - new_w - left
    
    padded = cv2.copyMakeBorder(
        resized, top, bottom, left, right, 
        cv2.BORDER_CONSTANT, value=[0, 0, 0]
    )
    return padded

def _otsu_fallback(gray_img: np.ndarray) -> np.ndarray:
    """
    Segmentazione polmonare classica usando la sogliatura di Otsu
    e operazioni morfologiche (fallback quando reti come U-Net falliscono).
    """
    # Sfocatura per ridurre il rumore
    blurred = cv2.GaussianBlur(gray_img, (5, 5), 0)
    
    # Sogliatura di Otsu (inverte la maschera perché i polmoni sono scuri sulla TAC)
    _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    # Operazioni morfologiche per pulire la maschera
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    return closing

def apply_clahe(img_channel: np.ndarray, clip_limit: float = 2.0, tile_grid: tuple = (8, 8)) -> np.ndarray:
    """
    Applica il Contrast Limited Adaptive Histogram Equalization (CLAHE).
    """
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid)
    return clahe.apply(img_channel)

def build_three_channel(gray_img: np.ndarray, clahe_limits: list = [2.0, 4.0]) -> np.ndarray:
    """
    Costruisce un'immagine a 3 canali: Originale, CLAHE leggero, CLAHE forte.
    Necessario per i modelli pre-addestrati che si aspettano 3 canali in input.
    """
    if len(gray_img.shape) == 3:
        gray_img = cv2.cvtColor(gray_img, cv2.COLOR_RGB2GRAY)
        
    ch1 = gray_img
    ch2 = apply_clahe(gray_img, clip_limit=clahe_limits[0])
    ch3 = apply_clahe(gray_img, clip_limit=clahe_limits[1])
    
    return np.stack([ch1, ch2, ch3], axis=-1)

def apply_lung_mask(img: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Azzera i pixel dell'immagine che si trovano fuori dalla maschera polmonare.
    """
    masked_img = cv2.bitwise_and(img, img, mask=mask)
    return masked_img

def get_train_transform(target_size: int = 224, mean=(0.475, 0.446, 0.433), std=(0.366, 0.348, 0.336)):
    """
    Pipeline di Data Augmentation per il training set.
    Include vincoli anatomici (niente flip verticale).
    """
    return A.Compose([
        A.HorizontalFlip(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1, rotate_limit=10, p=0.5),
        A.RandomBrightnessContrast(p=0.2),
        A.GaussNoise(p=0.2),
        A.Normalize(mean=mean, std=std),
        ToTensorV2(),
    ])

def get_eval_transform(target_size: int = 224, mean=(0.475, 0.446, 0.433), std=(0.366, 0.348, 0.336)):
    """
    Pipeline di valutazione (Validation/Test). Nessuna augmentation, solo normalizzazione.
    """
    return A.Compose([
        A.Normalize(mean=mean, std=std),
        ToTensorV2(),
    ])