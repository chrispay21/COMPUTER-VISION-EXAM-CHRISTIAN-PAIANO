import os
import random
import logging
import yaml
import numpy as np
import torch

# Workaround per evitare conflitti noti tra librerie native su Windows/Mac
os.environ["OUTDATED_IGNORE"] = "1"

def set_seed(seed: int = 42):
    """
    Fissa i generatori di numeri casuali per garantire la riproducibilità.
    Questo è un requisito fondamentale per l'esame.
    """
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    
    # PyTorch seed
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

def get_logger(name: str) -> logging.Logger:
    """
    Configura e restituisce un logger uniforme.
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
    logger.propagate = False
    return logger

def load_config(config_path: str) -> dict:
    """
    Carica i parametri di configurazione dal file YAML.
    """
    with open(config_path, 'r', encoding='utf-8') as file:
        config = yaml.safe_load(file)
    return config