import torch
import torch.nn as nn
import timm
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
from PIL import Image
import cv2  # Aggiunto per forzare il ridimensionamento

from src.preprocessing import get_train_transform, get_eval_transform
from src.utils import get_logger

logger = get_logger(__name__)

# Mappatura delle classi: COVID è la classe positiva (1)
LABEL_MAP = {'covid': 1, 'non-covid': 0}

class CovidCTDataset(Dataset):
    """
    Dataset custom per PyTorch. 
    Applica il preprocessing (augmentation, normalizzazione) "al volo" 
    per ogni batch durante l'addestramento.
    """
    def __init__(self, df: pd.DataFrame, transform=None):
        self.df = df
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        img_path = self.df.iloc[idx]['filepath']
        label_str = self.df.iloc[idx]['label']
        label = LABEL_MAP[label_str]

        # Carica l'immagine (in RGB)
        image = np.array(Image.open(img_path).convert("RGB"))
        
        # FIX DIMENSIONI: Forziamo l'immagine a 224x224 prima di passarla alla rete
        image = cv2.resize(image, (224, 224))

        if self.transform:
            augmented = self.transform(image=image)
            image = augmented['image']

        return image, torch.tensor(label, dtype=torch.long)

class CovidCTModel(nn.Module):
    """
    Architettura custom basata su EfficientNet-B0 pre-addestrata.
    Sostituiamo la 'testa' (head) originale con una nostra per la classificazione binaria.
    """
    def __init__(self, backbone_name: str = 'efficientnet_b0', pretrained: bool = True, dropout_rate: float = 0.5):
        super().__init__()
        # Carica il backbone senza la testa di classificazione originale (num_classes=0)
        self.backbone = timm.create_model(backbone_name, pretrained=pretrained, num_classes=0, global_pool="avg")
        
        # Recupera il numero di feature in uscita dal backbone
        num_features = self.backbone.num_features
        
        # Costruisce la nuova testa custom (Dropout -> Linear)
        self.head = nn.Sequential(
            nn.Dropout(dropout_rate),
            nn.Linear(num_features, 2)
        )

    def forward(self, x):
        features = self.backbone(x)
        logits = self.head(features)
        return logits

def build_model(config: dict) -> nn.Module:
    """
    Factory function per istanziare il modello usando i parametri nel file YAML.
    """
    arch = config['model']['architecture']
    pretrained = config['model']['pretrained']
    dropout = config['model']['dropout_rate']
    
    logger.info(f"Costruzione modello {arch} (Pretrained: {pretrained})")
    model = CovidCTModel(backbone_name=arch, pretrained=pretrained, dropout_rate=dropout)
    return model

def unfreeze_last_blocks(model: nn.Module, n_blocks: int = 2):
    """
    Sblocca gli ultimi n_blocks del backbone per la Fase 2 del fine-tuning.
    I primi blocchi rimangono 'congelati' (non addestrabili) per preservare
    le feature di base estratte da ImageNet.
    """
    # Prima congela tutto il backbone
    for param in model.backbone.parameters():
        param.requires_grad = False
        
    # Poi scongela solo gli ultimi blocchi (specifico per timm efficientnet)
    blocks = list(model.backbone.blocks)
    if n_blocks > len(blocks):
        n_blocks = len(blocks)
        
    for block in blocks[-n_blocks:]:
        for param in block.parameters():
            param.requires_grad = True
            
    # Assicuriamoci che la nostra testa sia sempre addestrabile
    for param in model.head.parameters():
        param.requires_grad = True