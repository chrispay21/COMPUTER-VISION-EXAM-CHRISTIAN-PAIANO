import numpy as np
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from src.utils import get_logger

logger = get_logger(__name__)

def train_svm(X_train: np.ndarray, y_train: np.ndarray, random_state: int = 42):
    """
    Addestra un modello SVM (Support Vector Machine) con kernel RBF.
    Applica prima uno StandardScaler e una PCA per ridurre le dimensioni
    delle feature (da >26k a 200) velocizzando enormemente l'addestramento.
    """
    logger.info("Inizializzazione pipeline SVM...")
    
    # Pipeline: Standardizzazione -> Riduzione dimensionale -> Classificatore
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('pca', PCA(n_components=200, random_state=random_state)),
        ('svc', SVC(kernel='rbf', probability=True, random_state=random_state))
    ])
    
    # Griglia degli iperparametri da testare per trovare la configurazione ottimale
    param_grid = {
        'svc__C': [0.1, 1, 10, 100],
        'svc__gamma': ['scale', 0.001, 0.01]
    }
    
    # Cross-validation a 5 fold stratificata
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    
    logger.info("Avvio Grid Search per SVM (potrebbe richiedere un po' di tempo)...")
    grid_search = GridSearchCV(pipeline, param_grid, cv=cv, scoring='roc_auc', n_jobs=-1, verbose=1)
    grid_search.fit(X_train, y_train)
    
    logger.info(f"Migliori parametri SVM trovati: {grid_search.best_params_}")
    return grid_search

def train_random_forest(X_train: np.ndarray, y_train: np.ndarray, random_state: int = 42):
    """
    Addestra una Random Forest.
    A differenza dell'SVM, gli alberi decisionali sono invarianti alla scala
    e non hanno bisogno di StandardScaler o PCA.
    """
    logger.info("Inizializzazione Random Forest...")
    
    rf = RandomForestClassifier(random_state=random_state)
    
    param_grid = {
        'n_estimators': [100, 300, 500],
        'max_depth': [None, 10, 20]
    }
    
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    
    logger.info("Avvio Grid Search per Random Forest...")
    grid_search = GridSearchCV(rf, param_grid, cv=cv, scoring='roc_auc', n_jobs=-1, verbose=1)
    grid_search.fit(X_train, y_train)
    
    logger.info(f"Migliori parametri RF trovati: {grid_search.best_params_}")
    return grid_search