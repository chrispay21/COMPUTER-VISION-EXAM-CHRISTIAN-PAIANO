import streamlit as st
import cv2
import numpy as np
from PIL import Image
import joblib
import sys
import os

# Aggiungiamo la root al path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.preprocessing import _otsu_fallback
from src.features import extract_handcrafted_features

# --- CONFIGURAZIONE PAGINA ---
st.set_page_config(page_title="COVID-CT Detector", page_icon="🫁", layout="centered")

st.title("🫁 Classificatore COVID-19 da TAC Toracica")
st.warning("⚠️ **DISCLAIMER:** Questo strumento è un prototipo accademico sviluppato per l'esame di Computer Vision. Non è destinato ad alcun uso clinico o diagnostico reale.")

# --- CARICAMENTO MODELLO ---
@st.cache_resource
def load_model():
    model_path = 'models/classical/svm.pkl'
    if os.path.exists(model_path):
        return joblib.load(model_path)
    return None

svm_model = load_model()

if svm_model is None:
    st.error("Modello SVM non trovato! Assicurati di aver eseguito 'python scripts/train_classical.py' per addestrare e salvare il modello.")
    st.stop()

# --- SIDEBAR E CONTROLLI ---
st.sidebar.header("Impostazioni Modello")
use_mask = st.sidebar.checkbox("Applica Maschera Polmonare (Otsu)", value=True, 
                               help="Isola i polmoni rimuovendo lo sfondo prima dell'estrazione delle feature.")
threshold = st.sidebar.slider("Soglia di Decisione (COVID)", min_value=0.0, max_value=1.0, value=0.50, step=0.01)

# --- UPLOAD IMMAGINE ---
uploaded_file = st.file_uploader("Carica una slice TAC (PNG, JPG)", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    # Mostra l'immagine caricata
    image = Image.open(uploaded_file).convert('RGB')
    img_array = np.array(image)
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Immagine Originale")
        st.image(image, use_container_width=True)
        
    with st.spinner("Estrazione feature e predizione in corso..."):
        # Preprocessing (Scala di grigi per HOG/LBP/GLCM)
        img_gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        
        mask = None
        if use_mask:
            mask = _otsu_fallback(img_gray)
            with col2:
                st.subheader("Maschera Estratta")
                # ERRORE RISOLTO: rimosso cmap='gray'
                st.image(mask, use_container_width=True)
        else:
            with col2:
                st.subheader("Maschera")
                st.info("Maschera disattivata dalle impostazioni.")

        # Estrazione feature
        features = extract_handcrafted_features(img_gray, lung_mask=mask)
        features_reshaped = features.reshape(1, -1)
        
        # Predizione
        prob_covid = svm_model.predict_proba(features_reshaped)[0, 1]
        
        st.markdown("---")
        st.subheader("Risultato Analisi")
        
        if prob_covid >= threshold:
            st.error(f"**PREDIZIONE: POSITIVO AL COVID-19**")
        else:
            st.success(f"**PREDIZIONE: NEGATIVO (Non-COVID)**")
            
        st.progress(float(prob_covid))
        st.write(f"Probabilità stimata dal modello (SVM): **{prob_covid:.2%}**")